from django.contrib import admin

from .models import Post, Courses

admin.site.register(Post)
admin.site.register(Courses)

